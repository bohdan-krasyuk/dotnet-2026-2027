﻿
// 1) lock
/*
int counter = 0;

var sync = new object();

void Work()
{
    for (int i = 0; i < 10_000_000; i++)
    {
        lock (sync)
        {
            counter++;
        }
    }
}

var t1 = new Thread(Work);
var t2 = new Thread(Work);

t1.Start();
t2.Start();

t1.Join();
t2.Join();

Console.WriteLine($"Expected 20_000_000, got {counter}");
*/

// 2) mutex
/*int balance = 100;

var mutex = new Mutex();

void Withdraw(object? who)
{
    mutex.WaitOne();
    try
    {
        if (balance >= 100)
        {
            Thread.Sleep(100);
            balance -= 100;
            Console.WriteLine($"{who} withdrawn 100");
        }
        else
        {
            Console.WriteLine($"{who}: not enough money");
        }
    }
    finally
    {
        mutex.ReleaseMutex();
    }
}

var t1 = new Thread(Withdraw);
var t2 = new Thread(Withdraw);
t1.Start("Bob");
t2.Start("John");
t1.Join();
t2.Join();
Console.WriteLine(balance);*/

var semaphore = new Semaphore(3, 3); // 3 free spaces, max 3
int parked = 0;

void Park(object? car)
{
    semaphore.WaitOne();
    int now = Interlocked.Increment(ref parked);
    Console.WriteLine($"{DateTime.Now:ss.f} car {car} parked, spaces used: {now}");
    Thread.Sleep(1000);
    Interlocked.Decrement(ref parked);
    Console.WriteLine($"{DateTime.Now:ss.f} car {car} left");
    semaphore.Release();
}

for (int i = 1; i <= 7; i++)
{
    new Thread(Park).Start(i);
}
